// import
let express = require("express");
let mongoose = require("mongoose");
const router = require("./routes");
// server
let server = express();
let PORT = 3001;
let URI = `mongodb+srv://user:user123@webapp.3fakb.mongodb.net/todoApp?retryWrites=true&w=majority&appName=WebApp`;

// enable post and put request data
server.use(express.json());
server.use(express.urlencoded({ extended: false }));

server.set("views", "./views");
server.set("view engine", "ejs");

server.use(express.static("public"));
// add routes to app
server.use(router);
console.log("connecting to database...");
mongoose
  .connect(URI)
  .then(() => {
    // port number
    server.listen(PORT, () => {
      console.log(`server is running on port ${PORT}`);
    });
  })
  .catch((error) => {
    console.log(error);
  });
