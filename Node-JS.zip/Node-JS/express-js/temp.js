function a() {}

a(function () {}); // es5
a(() => {}); // es6
// callback => function written in other function call
