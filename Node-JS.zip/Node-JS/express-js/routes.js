let express = require("express");
const mainController = require("./controller/main.controller");
let router = express.Router();
// route added
router.get("/", mainController.homePage);
router.get("/todo-list", mainController.todoList);
router.post("/save-todo", mainController.saveNewTodo);
router.get("/remove-todo/:id", mainController.removeTodo);

// export
module.exports = router;
