// import
let mongoose = require("mongoose");

// schema
let TodoSchema = new mongoose.Schema({
  todoName: { type: String },
});

// model
let TodoModel = mongoose.model("todo", TodoSchema, "todos");

module.exports = TodoModel;
