const TodoModel = require("../model/todo.model");

let mainController = {
  homePage(request, response) {
    response.render("index", {
      pageName: "Add Todo",
    });
  },
  async todoList(request, response) {
    try {
      let filter = {};
      let result = await TodoModel.find(filter);
      response.render("list", {
        pageName: "My List",
        list: result,
      });
    } catch (error) {
      response.send("Unable to read record, try again or contact to admin");
    }
  },
  async saveNewTodo(request, response) {
    let data = request.body;
    try {
      let newTodo = new TodoModel({
        todoName: data.todoName,
      });
      await newTodo.save();
      response.redirect("/todo-list");
    } catch (error) {
      response.send("Unable to save record, try again or contact to admin");
    }
  },
  async removeTodo(request, response) {
    let id = request.params.id;
    try {
      await TodoModel.findByIdAndDelete(id);
      response.redirect("/todo-list");
    } catch (error) {
      response.send("unable to remove");
    }
  },
};

// export
module.exports = mainController;
