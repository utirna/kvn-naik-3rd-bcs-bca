// core module
// 3rd party module
// custom module

// import
// let nameOfModule = require('nameOfModule')
// http
let http = require("http");

function requestListener(request, response) {
  response.write(`<h1 style="background-color:red">Welcome to node js</h1>`);
  response.end();
}

http.createServer(requestListener).listen(3000);

// create server

// add port number
