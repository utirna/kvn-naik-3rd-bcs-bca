let text = "Ankush";
let age = 24;
let calc = 20 + Number("20");
let isPresent = true;
let parentNumber;
// text = 1.1;
console.log(typeof text);
console.log(age);
console.log(calc);
console.log(typeof parentNumber);
// console.clear();
let array = [1, "a", true];
console.log(array);
//################################# functions

funName();

function funName() {
  console.log("hello");
} // function def
